# Kemus 2.0 — PC virtuel léger

> Inspiré **KDE Plasma** + **NixOS** + **Fedora**, exécuté dans le navigateur,
> zéro dépendance Python externe. Un seul fichier, ~3900 lignes, port **3922**.

## Quoi de neuf en v2.0 ?

| Brique | Description |
|---|---|
| **Terminal réel** | Pipes `cmd \| cmd`, redirections `> >> <`, conditionnels `&& \|\| ;`, env vars `$VAR`/`export`/`unset`/`env` |
| **55+ commandes** | + grep, head, tail, wc, sort, uniq, tee, xargs, less, more, seq, bc, printf, yes, diff, basename, dirname, realpath, file, stat, chmod, chown, ln, tar, which, hostname, uptime, man, curl (réel), wget (réel), ping |
| **8 thèmes** | Breeze Dark/Light, NixOS, Fedora, Dracula, Solarized-Dark, Tokyo Night, Nord |
| **Pro Réglages** | Onglets Apparence/Terminal/Systeme/Avance : theme picker, accent color, wallpaper, police + taille terminal, reset VFS, export JSON |
| **Logithèque** | 43 apps installables (Dev, Internet, System, Utilities, Multimedia, Games) — persistence dans `~/.kemus/installed.json` |
| **Browser réel** | DuckDuckGo via proxy `/api/search` + `/api/proxy` (SSRF-safe : bloque localhost et IPs privées) |
| **Man pages** | Offline pour 30+ commandes + fallback man7.org |
| **Workflow Studio** | Runner YAML temps réel via **SSE** (Server-Sent Events), format compatible GitHub Actions subset |
| **Monitor / Logs** | Process monitor live (top refresh 3s), tail live des logs Kemus |
| **Apps utilitaires** | Markdown preview, Notes (localStorage), Tâches, Calendrier, Horloge analogique, Color picker, Dictionnaire (DDG), Image viewer |
| **curl/wget réels** | Téléchargement réel vers le VFS, protection SSRF |

## Installation 1 commande

```bash
bash install.sh           # auto : installe puis LANCE Kemus
bash install.sh --port 4000  # port custom
```

Compatible **Ubuntu 24.04 / Debian 12+** (PEP 668) : chaîne de fallback automatique (pip → venv dédié → zero-install wrapper). Voir `install.sh --help`.

## Fonctionnalites

| Module           | Description                                                 |
|------------------|-------------------------------------------------------------|
| **Bureau**       | Gradient NixOS + wallpaper SVG flocon, panels KDE           |
| **Kickoff**      | Menu applications avec recherche, comme KDE Plasma          |
| **Dock**         | Barre d'icônes inferieure style Plasma                      |
| **Fenetres**     | Drag & drop, redimension, minimize/maximize/close, focus z   |
| **Terminal**     | Vrai shell : `ls cd cat mkdir touch rm mv cp find tree echo` |
|                  | `pwd date whoami uname neofetch ps top df free history`     |
|                  | `python -c "..."` (executé dans le sandbox VFS)             |
|                  | `apt/dnf/pacman/nix install|remove|search|list` (simulés)   |
|                  | `edit <file>` ouvre l'editeur ; `clear`, `exit`             |
| **Fichiers**     | Gestionnaire type Dolphin : sidebar + grille + mkdir/touch   |
| **Editeur**      | Type Kate : load/save via API `/api/file/save`               |
| **Calculatrice** | Type kcalc : eval safe (regex)                               |
| **Navigateur**   | Simule (iframe sandbox)                                      |
| **Parametres**   | Info systeme KemusOS                                         |
| **Aide**         | Raccourcis et commandes                                      |
| **Boot screen**  | Sequence de demarrage avec progress bar                      |
| **Toasts**       | Notifications type Plasma                                    |

## VFS reel (le vrai PC)

Tous les fichiers que vous créez dans le terminal (`touch`, `mkdir`, `echo >`,
`edit`) sont **persistants sur disque** :

```
~/.kemus/
├── home/           <- VFS racine (cd ~ ici)
│   ├── README.txt
│   ├── hello.py
│   ├── Documents/
│   ├── Projects/
│   └── ...
├── kemus.log       <- logs du serveur
```

Vous pouvez `cat`, `edit`, `python hello.py` depuis le terminal — les fichiers
existent vraiment.

## API HTTP

| Endpoint                  | Methode | Description                       |
|---------------------------|---------|-----------------------------------|
| `/`                       | GET     | Page HTML du bureau               |
| `/api/health`             | GET     | `{ok, version, uptime}`           |
| `/api/desktop`            | GET     | Info distribution                 |
| `/api/fs?path=`           | GET     | Liste un dossier                  |
| `/api/file?path=`         | GET     | Lit un fichier                    |
| `/api/file/save`          | POST    | Sauvegarde `{path, content}`      |
| `/api/terminal`           | POST    | Execute `{cmd, cwd}` -> `{output, cwd, session, prompt}` |

## Sessions

Chaque onglet a une session (`kemus_session` cookie), donc le `cwd` du
terminal et l'historique sont persistants entre les requetes.

## Architecture

```
┌─────────────────────────────────────────────────────────┐
│  Navigateur (Firefox/Chrome)                             │
│   HTML/CSS/JS embarque dans kemus.py                     │
│   Window manager + Terminal client + Apps                │
└────────────────────────┬────────────────────────────────┘
                         │ HTTP localhost:3922
                         │  (fetch POST /api/*)
┌────────────────────────▼────────────────────────────────┐
│  Python kemus.py (ThreadingHTTPServer, stdlib only)      │
│   - run_command(cmd, cwd) -> 30+ commandes               │
│   - VFS reel via pathlib, sandboxe sous VFS_ROOT          │
│   - Sessions en memoire (cwd + history)                  │
└─────────────────────────────────────────────────────────┘
                         │
                         ▼
                  ~/.kemus/home/   (disque reel, persistant)
```

## Limitations

- Pas de reseau sortant dans le terminal (sandbox volontaire)
- `python -c` s'execute en subprocess 10s max (timeout)
- 1 session = 1 onglet ; pas de partage multi-onglet
- Le VFS est sandboxe : `cd /etc` echoue volontairement

## Roadmap

- WebSocket pour output streaming (longues commandes)
- Multi-utilisateurs
- Theme Breeze clair
- Paquet `kemus-themes` separable

## Licence

MIT.
